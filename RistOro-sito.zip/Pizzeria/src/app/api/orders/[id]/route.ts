import { NextResponse } from "next/server";
import { getOrderWithItems } from "@/lib/orders";
import { syncPayment } from "@/lib/payments";
import { toPublicOrder } from "@/lib/public-order";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Dettaglio ordine per la pagina di tracciamento (l'UUID fa da chiave d'accesso) */
export async function GET(_req: Request, ctx: RouteContext<"/api/orders/[id]">) {
  const { id } = await ctx.params;
  if (!UUID.test(id)) return NextResponse.json({ error: "Ordine non trovato" }, { status: 404 });
  let order = await getOrderWithItems(id);
  if (!order) return NextResponse.json({ error: "Ordine non trovato" }, { status: 404 });
  if (order.status === "in_attesa_pagamento") {
    await syncPayment(id).catch((e) => console.error(e));
    order = (await getOrderWithItems(id)) ?? order;
  }
  return NextResponse.json(toPublicOrder(order), { headers: { "Cache-Control": "no-store" } });
}
