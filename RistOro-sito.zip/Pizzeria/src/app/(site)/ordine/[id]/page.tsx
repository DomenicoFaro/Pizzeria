import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { OrderTracker } from "@/components/order/OrderTracker";
import { getOrderWithItems } from "@/lib/orders";
import { syncPayment } from "@/lib/payments";
import { toPublicOrder } from "@/lib/public-order";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Il tuo ordine", robots: { index: false } };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function OrderPage({ params, searchParams }: PageProps<"/ordine/[id]">) {
  const { id } = await params;
  const sp = await searchParams;
  if (!UUID.test(id)) notFound();
  let order = await getOrderWithItems(id);
  if (!order) notFound();
  if (order.status === "in_attesa_pagamento") {
    await syncPayment(id).catch((e) => console.error(e));
    order = (await getOrderWithItems(id)) ?? order;
  }
  return (
    <div className="bg-farina px-4 pb-24 pt-[calc(var(--header-h)+2rem)] sm:px-6">
      <OrderTracker initial={toPublicOrder(order)} justPlaced={Boolean(sp.nuovo || sp.pagato || sp.payment_intent)} />
    </div>
  );
}
