import "server-only";
import { sendOrderConfirmation } from "./email";
import { getOrderWithItems } from "./orders";
import { getStripe, isStripeConfigured, toCents } from "./stripe";
import { getServiceSupabase } from "./supabase/server";

/**
 * Allinea lo stato di pagamento di un ordine con Stripe.
 * Chiamata dal webhook e, come rete di sicurezza, dalla pagina di tracciamento.
 */
export async function syncPayment(orderId: string): Promise<void> {
  if (!isStripeConfigured) return;
  const order = await getOrderWithItems(orderId);
  if (!order || order.payment_method !== "online" || !order.stripe_payment_id) return;
  if (order.payment_status !== "pending") return;

  const intent = await getStripe().paymentIntents.retrieve(order.stripe_payment_id);
  const sb = getServiceSupabase();
  if (intent.status === "succeeded") {
    if (intent.amount_received !== toCents(order.total)) {
      console.error(`Importo Stripe diverso dal totale ordine ${order.number}`);
    }
    // aggiornamento condizionale: evita doppie email se webhook e pagina arrivano insieme
    const { data } = await sb
      .from("orders")
      .update({ payment_status: "paid", status: "nuovo" })
      .eq("id", orderId)
      .eq("payment_status", "pending")
      .select("id");
    if (data?.length) {
      const fresh = await getOrderWithItems(orderId);
      if (fresh) await sendOrderConfirmation(fresh);
    }
  } else if (intent.status === "canceled") {
    await sb
      .from("orders")
      .update({ payment_status: "failed", status: "annullato", status_reason: "Pagamento non completato" })
      .eq("id", orderId)
      .eq("payment_status", "pending");
  }
}

/** Rimborso automatico per ordini pagati online e poi rifiutati/annullati */
export async function refundIfPaid(orderId: string): Promise<boolean> {
  const order = await getOrderWithItems(orderId);
  if (!order || order.payment_method !== "online" || order.payment_status !== "paid" || !order.stripe_payment_id) return false;
  await getStripe().refunds.create({ payment_intent: order.stripe_payment_id });
  await getServiceSupabase().from("orders").update({ payment_status: "refunded" }).eq("id", orderId);
  return true;
}
