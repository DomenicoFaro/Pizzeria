import "server-only";
import Stripe from "stripe";

let stripe: Stripe | null = null;

export const isStripeConfigured = Boolean(process.env.STRIPE_SECRET_KEY);

export function getStripe(): Stripe {
  if (!process.env.STRIPE_SECRET_KEY) throw new Error("STRIPE_SECRET_KEY mancante");
  if (!stripe) stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  return stripe;
}

export const toCents = (euro: number) => Math.round(euro * 100);
