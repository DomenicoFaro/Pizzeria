import "server-only";

export type GeocodeResult = { lat: number; lng: number; formatted: string; city?: string };

/**
 * Geocodifica un indirizzo. Usa Google Geocoding se è configurata GOOGLE_MAPS_API_KEY,
 * altrimenti OpenStreetMap Nominatim (gratuito, max 1 richiesta/secondo).
 */
export async function geocodeAddress(q: { street: string; number?: string; city: string; cap?: string }): Promise<GeocodeResult | null> {
  const line = `${q.street}${q.number ? " " + q.number : ""}, ${q.cap ? q.cap + " " : ""}${q.city}, Catania, Italia`;
  const key = process.env.GOOGLE_MAPS_API_KEY;
  try {
    if (key) {
      const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(line)}&region=it&language=it&key=${key}`;
      const res = await fetch(url, { cache: "no-store" });
      const data = await res.json();
      const r = data.results?.[0];
      if (!r) return null;
      const city = r.address_components?.find((c: { types: string[] }) => c.types.includes("locality"))?.long_name;
      return { lat: r.geometry.location.lat, lng: r.geometry.location.lng, formatted: r.formatted_address, city };
    }
    const params = new URLSearchParams({
      street: `${q.number ? q.number + " " : ""}${q.street}`,
      city: q.city,
      county: "Catania",
      country: "Italia",
      format: "jsonv2",
      addressdetails: "1",
      limit: "1",
    });
    if (q.cap) params.set("postalcode", q.cap);
    let res = await fetch(`https://nominatim.openstreetmap.org/search?${params}`, {
      headers: { "User-Agent": "RistOroDellEtna/1.0 (ordini online)", "Accept-Language": "it" },
      cache: "no-store",
    });
    let data = await res.json();
    if (!data?.length) {
      // riprovo con ricerca libera (civici non sempre mappati su OSM)
      res = await fetch(`https://nominatim.openstreetmap.org/search?${new URLSearchParams({ q: line, format: "jsonv2", limit: "1", addressdetails: "1" })}`, {
        headers: { "User-Agent": "RistOroDellEtna/1.0 (ordini online)", "Accept-Language": "it" },
        cache: "no-store",
      });
      data = await res.json();
    }
    const r = data?.[0];
    if (!r) return null;
    const a = r.address ?? {};
    return { lat: Number(r.lat), lng: Number(r.lon), formatted: r.display_name, city: a.town ?? a.city ?? a.village };
  } catch (e) {
    console.error("geocode error", e);
    return null;
  }
}
