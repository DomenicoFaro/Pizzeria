/* Scena del hero: l'Etna al tramonto con il bagliore del forno a legna */
export function HeroArt() {
  return (
    <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#141211" />
          <stop offset=".55" stopColor="#2a1a14" />
          <stop offset=".8" stopColor="#5a2518" />
          <stop offset="1" stopColor="#1c1a19" />
        </linearGradient>
        <radialGradient id="glow" cx="50%" cy="100%" r="70%">
          <stop offset="0" stopColor="#c8412b" stopOpacity=".55" />
          <stop offset=".5" stopColor="#c8412b" stopOpacity=".12" />
          <stop offset="1" stopColor="#c8412b" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="crater" cx="50%" cy="0%" r="60%">
          <stop offset="0" stopColor="#ff8a4c" stopOpacity=".9" />
          <stop offset="1" stopColor="#c8412b" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="mount" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#3a3633" />
          <stop offset="1" stopColor="#1c1a19" />
        </linearGradient>
      </defs>
      <rect width="1440" height="900" fill="url(#sky)" />
      {/* stelle */}
      {Array.from({ length: 40 }).map((_, i) => (
        <circle key={i} cx={(i * 367) % 1440} cy={(i * 131) % 330} r={i % 5 === 0 ? 1.6 : 0.9} fill="#f6f0e6" opacity={0.25 + (i % 4) * 0.12} />
      ))}
      {/* fumo */}
      <g opacity=".35" fill="#6b635c">
        <ellipse cx="760" cy="250" rx="70" ry="30" />
        <ellipse cx="820" cy="200" rx="90" ry="34" />
        <ellipse cx="900" cy="150" rx="120" ry="38" />
        <ellipse cx="1010" cy="110" rx="150" ry="40" />
      </g>
      {/* montagna */}
      <path d="M0 720 L380 520 L560 420 L690 330 L735 300 L790 300 L830 330 L980 430 L1160 540 L1440 690 L1440 900 L0 900 Z" fill="url(#mount)" />
      <path d="M690 330 L735 300 L790 300 L830 330 L800 350 L770 335 L745 360 L715 345 Z" fill="#f6f0e6" opacity=".22" />
      <ellipse cx="762" cy="300" rx="60" ry="24" fill="url(#crater)" />
      {/* colata di lava */}
      <path d="M770 305 C 760 360, 800 400, 780 460 S 820 560, 800 640" stroke="#c8412b" strokeWidth="5" fill="none" opacity=".7" strokeLinecap="round" />
      <path d="M770 305 C 760 360, 800 400, 780 460 S 820 560, 800 640" stroke="#ffb46b" strokeWidth="1.5" fill="none" opacity=".8" strokeLinecap="round" />
      {/* colline vicine */}
      <path d="M0 780 Q 300 700 620 760 T 1440 740 L1440 900 L0 900 Z" fill="#161413" />
      <rect width="1440" height="900" fill="url(#glow)" />
    </svg>
  );
}
