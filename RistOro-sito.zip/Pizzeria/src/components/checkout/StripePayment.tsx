"use client";

import { Elements, PaymentElement, useElements, useStripe } from "@stripe/react-stripe-js";
import { loadStripe, type Stripe } from "@stripe/stripe-js";
import { useState } from "react";
import { Lock } from "lucide-react";
import { formatEuro } from "@/lib/pricing";

let stripePromise: Promise<Stripe | null> | null = null;
function getStripe() {
  const key = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;
  if (!key) return null;
  stripePromise ??= loadStripe(key);
  return stripePromise;
}

export const isStripeEnabled = Boolean(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY);

export function StripePayment({ clientSecret, orderId, total }: { clientSecret: string; orderId: string; total: number }) {
  return (
    <Elements
      stripe={getStripe()}
      options={{
        clientSecret,
        locale: "it",
        appearance: {
          theme: "stripe",
          variables: { colorPrimary: "#c8412b", colorText: "#1c1a19", borderRadius: "12px", fontFamily: "Inter, system-ui, sans-serif" },
        },
      }}
    >
      <PayForm orderId={orderId} total={total} />
    </Elements>
  );
}

function PayForm({ orderId, total }: { orderId: string; total: number }) {
  const stripe = useStripe();
  const elements = useElements();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const pay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setBusy(true);
    setError(null);
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: { return_url: `${window.location.origin}/ordine/${orderId}?pagato=1` },
    });
    // se arriviamo qui c'è stato un errore (altrimenti Stripe reindirizza)
    setError(error?.message ?? "Pagamento non riuscito. Riprova.");
    setBusy(false);
  };

  return (
    <form onSubmit={pay} className="space-y-4">
      <PaymentElement options={{ layout: "tabs", wallets: { applePay: "auto", googlePay: "auto" } }} />
      {error && <p className="rounded-xl bg-brace/10 p-3 text-sm text-brace" role="alert">{error}</p>}
      <button
        type="submit"
        disabled={!stripe || busy}
        className="flex h-14 w-full items-center justify-center gap-2 rounded-full bg-brace text-lg font-semibold text-white shadow-lg shadow-brace/25 hover:bg-brace-dark disabled:opacity-60"
      >
        <Lock className="h-5 w-5" aria-hidden="true" />
        {busy ? "Pagamento in corso…" : `Paga ${formatEuro(total)}`}
      </button>
      <p className="text-center text-xs text-pietra">Pagamento sicuro gestito da Stripe. Non conserviamo i dati della tua carta.</p>
    </form>
  );
}
