/* Illustrazioni segnaposto per i piatti senza foto (sostituite dalle foto caricate da admin) */

type Kind = "pizza" | "brace" | "primi" | "antipasti" | "insalate" | "dolci" | "bevande";

export function kindFromSlug(slug: string | undefined): Kind {
  if (!slug) return "pizza";
  if (slug.includes("pizz")) return "pizza";
  if (slug.includes("brace") || slug.includes("carne")) return "brace";
  if (slug.includes("prim") || slug.includes("pasta")) return "primi";
  if (slug.includes("insalat")) return "insalate";
  if (slug.includes("dolc")) return "dolci";
  if (slug.includes("bevand") || slug.includes("vin")) return "bevande";
  return "antipasti";
}

/** arrotondo le coordinate: Math.cos/sin possono differire tra server e browser (hydration) */
const r1 = (n: number) => Math.round(n * 10) / 10;

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export function FoodArt({ kind, seed = "", className = "" }: { kind: Kind; seed?: string; className?: string }) {
  const h = hash(seed);
  const rot = h % 360;
  const bg =
    kind === "brace" ? ["#2a2725", "#3a1d14"] : kind === "bevande" ? ["#2a2725", "#3b2e1a"] : kind === "insalate" ? ["#efe6d4", "#dfe8cf"] : ["#f3e6cc", "#ead2a8"];

  return (
    <svg viewBox="0 0 200 150" className={className} role="img" aria-hidden="true" preserveAspectRatio="xMidYMid slice">
      <defs>
        <radialGradient id={`bg-${kind}-${h}`} cx="50%" cy="45%" r="75%">
          <stop offset="0" stopColor={bg[0]} />
          <stop offset="1" stopColor={bg[1]} />
        </radialGradient>
        <radialGradient id={`crust-${h}`} cx="50%" cy="50%" r="50%">
          <stop offset=".78" stopColor="#e9b872" />
          <stop offset=".9" stopColor="#c98a3e" />
          <stop offset="1" stopColor="#8a5520" />
        </radialGradient>
      </defs>
      <rect width="200" height="150" fill={`url(#bg-${kind}-${h})`} />
      {kind === "pizza" && (
        <g transform={`rotate(${rot} 100 78)`}>
          <ellipse cx="100" cy="82" rx="70" ry="60" fill="#000" opacity=".12" />
          <circle cx="100" cy="76" r="62" fill={`url(#crust-${h})`} />
          <circle cx="100" cy="76" r="50" fill={h % 3 === 0 ? "#f5ecd6" : "#c8412b"} />
          {h % 3 !== 0 && <circle cx="100" cy="76" r="50" fill="#b3321f" opacity=".35" />}
          {[...Array(6)].map((_, i) => {
            const a = (i / 6) * Math.PI * 2 + (h % 7);
            const r = 18 + ((h >> i) % 18);
            return <ellipse key={i} cx={r1(100 + Math.cos(a) * r)} cy={r1(76 + Math.sin(a) * r)} rx="11" ry="9" fill="#fbf6ea" opacity=".95" />;
          })}
          {[...Array(4)].map((_, i) => {
            const a = (i / 4) * Math.PI * 2 + 0.6;
            return <path key={i} d={`M${r1(100 + Math.cos(a) * 30)} ${r1(76 + Math.sin(a) * 30)} q5 -8 10 0 q-5 6 -10 0z`} fill="#4e7a3a" />;
          })}
          {h % 2 === 0 && [...Array(10)].map((_, i) => <circle key={i} cx={70 + ((h >> i) % 60)} cy={50 + ((h >> (i + 2)) % 55)} r="1.6" fill="#8fb34a" />)}
        </g>
      )}
      {kind === "brace" && (
        <g>
          {[...Array(7)].map((_, i) => (
            <rect key={i} x="20" y={40 + i * 12} width="160" height="3" rx="1.5" fill="#6b635c" opacity=".7" />
          ))}
          <path d="M55 60 q45 -25 95 5 q10 30 -30 40 q-55 8 -70 -15 q-5 -20 5 -30z" fill="#7a3a22" />
          <path d="M60 70 q40 -20 85 3" stroke="#3a1d14" strokeWidth="5" fill="none" opacity=".7" />
          <path d="M62 84 q40 -18 82 3" stroke="#3a1d14" strokeWidth="5" fill="none" opacity=".7" />
          <path d="M92 118 c-10 -14 6 -18 0 -30 c14 8 16 18 8 30z" fill="#c8412b" />
          <path d="M104 120 c-6 -10 5 -12 1 -21 c9 6 10 13 4 21z" fill="#d4a24c" />
        </g>
      )}
      {kind === "primi" && (
        <g>
          <ellipse cx="100" cy="85" rx="72" ry="50" fill="#000" opacity=".1" />
          <ellipse cx="100" cy="78" rx="70" ry="48" fill="#fbf8f2" />
          <ellipse cx="100" cy="78" rx="50" ry="33" fill="#f1e7d4" />
          {[...Array(9)].map((_, i) => (
            <rect key={i} x={70 + (i % 3) * 20 + ((h >> i) % 6)} y={60 + Math.floor(i / 3) * 12} width="16" height="7" rx="3.5" transform={`rotate(${(h >> i) % 50 - 25} ${78 + (i % 3) * 20} ${63 + Math.floor(i / 3) * 12})`} fill="#e7b85a" />
          ))}
          <path d="M72 70 q28 -12 56 4 q-8 22 -30 22 q-24 -2 -26 -26z" fill="#b3321f" opacity=".55" />
          <circle cx="112" cy="70" r="4" fill="#4e7a3a" />
        </g>
      )}
      {kind === "antipasti" && (
        <g>
          <rect x="25" y="35" width="150" height="85" rx="14" fill="#9a6b3e" />
          <rect x="25" y="35" width="150" height="85" rx="14" fill="none" stroke="#6e4726" strokeWidth="3" />
          {[...Array(3)].map((_, i) => (
            <g key={i} transform={`translate(${45 + i * 42} ${55 + (i % 2) * 8})`}>
              <rect width="34" height="22" rx="6" fill="#e6c28a" />
              <rect x="3" y="3" width="28" height="12" rx="4" fill="#c8412b" />
              <circle cx="10" cy="8" r="2" fill="#4e7a3a" />
            </g>
          ))}
          <path d="M45 98 q15 -8 30 0 q-15 8 -30 0z" fill="#e8a7a0" />
          <circle cx="130" cy="100" r="9" fill="#f7efd9" />
          <circle cx="150" cy="98" r="6" fill="#4b3a2a" />
        </g>
      )}
      {kind === "insalate" && (
        <g>
          <ellipse cx="100" cy="80" rx="68" ry="48" fill="#fbf8f2" />
          {[...Array(8)].map((_, i) => (
            <ellipse key={i} cx={75 + (i % 4) * 16} cy={62 + Math.floor(i / 4) * 22} rx="16" ry="10" transform={`rotate(${i * 40} ${75 + (i % 4) * 16} ${62 + Math.floor(i / 4) * 22})`} fill={i % 2 ? "#6f9e45" : "#8fb34a"} />
          ))}
          <circle cx="90" cy="72" r="8" fill="#c8412b" />
          <circle cx="118" cy="88" r="7" fill="#c8412b" />
          <circle cx="104" cy="66" r="9" fill="#fbf6ea" />
        </g>
      )}
      {kind === "dolci" && (
        <g>
          <ellipse cx="100" cy="95" rx="60" ry="22" fill="#fbf8f2" />
          <rect x="62" y="62" width="76" height="30" rx="15" fill="#d9a35e" transform="rotate(-12 100 77)" />
          <ellipse cx="66" cy="84" rx="9" ry="12" fill="#f7efd9" transform="rotate(-12 100 77)" />
          <ellipse cx="134" cy="70" rx="9" ry="12" fill="#f7efd9" transform="rotate(-12 100 77)" />
          {[...Array(6)].map((_, i) => <circle key={i} cx={60 + i * 3} cy={80 + (i % 2) * 5} r="1.8" fill="#6f9e45" />)}
          {[...Array(6)].map((_, i) => <circle key={i} cx={133 + (i % 3) * 3} cy={65 + i * 2} r="1.8" fill="#6f9e45" />)}
        </g>
      )}
      {kind === "bevande" && (
        <g>
          <path d="M80 30 h14 v22 q14 8 14 26 v48 q0 6 -6 6 h-30 q-6 0 -6 -6 v-48 q0 -18 14 -26z" fill="#5b1e1a" />
          <rect x="80" y="26" width="14" height="8" rx="2" fill="#d4a24c" />
          <rect x="72" y="84" width="30" height="24" rx="3" fill="#f6f0e6" />
          <path d="M122 70 h30 q0 26 -15 28 q-15 -2 -15 -28z" fill="#8a1f1a" opacity=".85" />
          <rect x="136" y="98" width="2.5" height="22" fill="#e8e1d6" />
          <rect x="126" y="119" width="22" height="3" rx="1.5" fill="#e8e1d6" />
        </g>
      )}
    </svg>
  );
}
