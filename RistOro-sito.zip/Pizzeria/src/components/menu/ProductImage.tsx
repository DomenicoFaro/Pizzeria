import Image from "next/image";
import { FoodArt, kindFromSlug } from "./FoodArt";

export function ProductImage({
  src,
  alt,
  categorySlug,
  seed,
  sizes = "(max-width: 640px) 40vw, 240px",
  className = "",
  priority = false,
}: {
  src: string | null;
  alt: string;
  categorySlug?: string;
  seed: string;
  sizes?: string;
  className?: string;
  priority?: boolean;
}) {
  return (
    <div className={`relative overflow-hidden bg-crema-dark ${className}`}>
      {src ? (
        <Image src={src} alt={alt} fill sizes={sizes} className="object-cover" priority={priority} />
      ) : (
        <FoodArt kind={kindFromSlug(categorySlug)} seed={seed} className="h-full w-full" />
      )}
    </div>
  );
}
